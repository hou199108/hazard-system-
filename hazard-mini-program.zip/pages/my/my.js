const app = getApp()

Page({
  data: {
    userInfo: {},
    myStats: {
      total: 0,
      pending: 0,
      completed: 0
    }
  },

  onShow() {
    this.loadUserInfo()
    this.loadMyStats()
  },

  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo') || {}
    this.setData({ userInfo })
  },

  async loadMyStats() {
    // 这里应该调用API获取当前用户的统计数据
    // 暂时使用模拟数据
    this.setData({
      myStats: {
        total: 0,
        pending: 0,
        completed: 0
      }
    })
  },

  goToMyReports() {
    wx.navigateTo({
      url: '/pages/list/list'
    })
  },

  showAbout() {
    wx.showModal({
      title: '关于我们',
      content: '隐患排查小程序是一款专业的安全隐患上报与管理工具，致力于帮助社会公众及时发现和消除各类安全隐患，共建平安社会。',
      showCancel: false
    })
  },

  showHelp() {
    wx.showModal({
      title: '使用帮助',
      content: '1. 点击首页分类图标或底部"上报"按钮可上报隐患\n2. 上报时请填写详细信息并上传现场照片\n3. 可在"记录"页面查看所有隐患处理进度\n4. 如有问题请联系管理员',
      showCancel: false
    })
  }
})
