const app = getApp()

Page({
  data: {
    categories: [],
    hazards: [],
    keyword: '',
    selectedCategoryId: '',
    statusOptions: [
      { label: '全部状态', value: '' },
      { label: '待处理', value: '待处理' },
      { label: '处理中', value: '处理中' },
      { label: '已处理', value: '已处理' }
    ],
    statusIndex: 0,
    page: 1,
    pageSize: 10,
    total: 0,
    hasMore: true,
    loading: false
  },

  onLoad() {
    this.fetchCategories()
    this.fetchHazards()
  },

  onShow() {
    this.refreshList()
  },

  onPullDownRefresh() {
    this.refreshList()
    wx.stopPullDownRefresh()
  },

  async fetchCategories() {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/categories`,
        method: 'GET',
        header: { 'Authorization': `Bearer ${wx.getStorageSync('token')}` }
      })
      this.setData({ categories: res.data.data })
    } catch (error) {
      console.error('获取分类失败', error)
    }
  },

  async fetchHazards(append = false) {
    if (this.data.loading) return
    
    this.setData({ loading: true })

    try {
      const { keyword, selectedCategoryId, statusOptions, statusIndex, page, pageSize } = this.data
      const params = {
        keyword,
        category_id: selectedCategoryId,
        status: statusOptions[statusIndex].value,
        page,
        pageSize
      }

      const res = await wx.request({
        url: `${app.globalData.baseUrl}/hazards`,
        method: 'GET',
        data: params,
        header: { 'Authorization': `Bearer ${wx.getStorageSync('token')}` }
      })

      if (!res.data || !res.data.data) {
        this.setData({ loading: false });
        return;
      }

      const list = (res.data.data.list || []).map(item => ({
        ...item,
        created_at: this.formatDate(item.created_at)
      }))

      this.setData({
        hazards: append ? [...this.data.hazards, ...list] : list,
        total: res.data.data.total,
        hasMore: list.length === pageSize
      })
    } catch (error) {
      console.error('获取隐患列表失败', error)
    } finally {
      this.setData({ loading: false })
    }
  },

  formatDate(dateStr) {
    if (!dateStr) return ''
    const date = new Date(dateStr)
    return `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`
  },

  refreshList() {
    this.setData({ page: 1, hasMore: true })
    this.fetchHazards()
  },

  onKeywordInput(e) {
    this.setData({ keyword: e.detail.value })
  },

  onSearch() {
    this.refreshList()
  },

  onStatusChange(e) {
    this.setData({ statusIndex: e.detail.value })
    this.refreshList()
  },

  selectCategory(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ selectedCategoryId: id })
    this.refreshList()
  },

  loadMore() {
    if (!this.data.hasMore || this.data.loading) return
    this.setData({ page: this.data.page + 1 })
    this.fetchHazards(true)
  },

  goToDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    })
  }
})
