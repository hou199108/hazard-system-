const app = getApp()

Page({
  data: {
    categories: [],
    hazardTypes: [],
    categoryIndex: 0,
    typeIndex: 0,
    selectedCategory: null,
    selectedType: null,
    images: [],
    aiData: null,
    form: {
      title: '',
      description: '',
      ai_description: '',
      location: '',
      latitude: null,
      longitude: null,
      risk_level: '一般'
    },
    submitting: false
  },

  onLoad(options) {
    // 检查登录
    const userInfo = wx.getStorageSync('userInfo')
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      setTimeout(() => {
        wx.switchTab({ url: '/pages/index/index' })
      }, 1500)
      return
    }

    this.fetchCategories()

    // 处理AI识别结果
    if (options.aiData) {
      try {
        const aiData = JSON.parse(decodeURIComponent(options.aiData))
        this.setData({ 
          aiData,
          'form.title': aiData.title,
          'form.description': aiData.ai_description,
          'form.ai_description': aiData.ai_description
        })
        if (aiData.image) {
          this.setData({ images: [aiData.image] })
        }
      } catch (e) {
        console.error('解析AI数据失败', e)
      }
    } else if (options.categoryId) {
      // 预选分类
    }
  },

  async fetchCategories() {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/categories`,
        method: 'GET'
      })
      this.setData({ categories: res.data.data || [] })
      
      // 如果有AI数据，自动选择分类
      if (this.data.aiData && this.data.aiData.category_id) {
        const index = res.data.data.findIndex(c => c.id === this.data.aiData.category_id)
        if (index >= 0) {
          this.setData({ 
            categoryIndex: index,
            selectedCategory: res.data.data[index]
          })
          this.fetchHazardTypes(this.data.aiData.category_id)
        }
      }
    } catch (error) {
      console.error('获取分类失败', error)
    }
  },

  async fetchHazardTypes(categoryId) {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/categories/${categoryId}/types`,
        method: 'GET'
      })
      this.setData({ 
        hazardTypes: res.data.data,
        typeIndex: 0,
        selectedType: res.data.data[0] || null
      })
      
      // 如果有AI数据，自动选择隐患类型
      if (this.data.aiData && this.data.aiData.hazard_type_id) {
        const index = res.data.data.findIndex(t => t.id === this.data.aiData.hazard_type_id)
        if (index >= 0) {
          this.setData({
            typeIndex: index,
            selectedType: res.data.data[index]
          })
        }
      }
    } catch (error) {
      console.error('获取隐患类型失败', error)
    }
  },

  onCategoryChange(e) {
    const index = e.detail.value
    const category = this.data.categories[index]
    this.setData({
      categoryIndex: index,
      selectedCategory: category
    })
    this.fetchHazardTypes(category.id)
  },

  onTypeChange(e) {
    const index = e.detail.value
    this.setData({
      typeIndex: index,
      selectedType: this.data.hazardTypes[index]
    })
  },

  onTitleInput(e) {
    this.setData({ 'form.title': e.detail.value })
  },

  onDescInput(e) {
    this.setData({ 'form.description': e.detail.value })
  },

  selectRisk(e) {
    const level = e.currentTarget.dataset.level
    this.setData({ 'form.risk_level': level })
  },

  chooseLocation() {
    wx.chooseLocation({
      success: (res) => {
        this.setData({
          'form.location': res.address || res.name,
          'form.latitude': res.latitude,
          'form.longitude': res.longitude
        })
      },
      fail: () => {
        wx.getLocation({
          type: 'gcj02',
          success: (res) => {
            this.setData({
              'form.latitude': res.latitude,
              'form.longitude': res.longitude
            })
          }
        })
      }
    })
  },

  chooseImage() {
    const count = 5 - this.data.images.length
    wx.chooseMedia({
      count: count,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newImages = res.tempFiles.map(f => f.tempFilePath)
        this.setData({
          images: [...this.data.images, ...newImages]
        })
      }
    })
  },

  previewImage(e) {
    const url = e.currentTarget.dataset.url
    wx.previewImage({
      current: url,
      urls: this.data.images
    })
  },

  deleteImage(e) {
    const index = e.currentTarget.dataset.index
    const images = this.data.images.filter((_, i) => i !== index)
    this.setData({ images })
  },

  async submitForm() {
    const { form, selectedCategory, selectedType, images } = this.data
    const userInfo = wx.getStorageSync('userInfo')

    // 验证
    if (!form.title) {
      return wx.showToast({ title: '请输入隐患标题', icon: 'none' })
    }
    if (!form.location) {
      return wx.showToast({ title: '请选择地理位置', icon: 'none' })
    }

    this.setData({ submitting: true })

    try {
      // 上传图片
      let uploadedImages = []
      for (let img of images) {
        // 如果是本地临时文件才上传
        if (img.startsWith('wxfile://') || img.startsWith('http://tmp/') || img.startsWith('https://tmp/')) {
          const uploadRes = await wx.uploadFile({
            url: `${app.globalData.baseUrl}/hazards`,
            filePath: img,
            name: 'images'
          })
        } else {
          uploadedImages.push(img)
        }
      }

      // 提交表单
      const submitData = {
        category_id: selectedCategory?.id,
        hazard_type_id: selectedType?.id,
        title: form.title,
        description: form.description,
        ai_description: form.ai_description,
        location: form.location,
        latitude: form.latitude,
        longitude: form.longitude,
        risk_level: form.risk_level,
        images: uploadedImages.join(',')
      }

      const res = await wx.request({
        url: `${app.globalData.baseUrl}/hazards`,
        method: 'POST',
        data: submitData,
        header: { 
          'content-type': 'application/json',
          'Authorization': `Bearer ${wx.getStorageSync('token')}`
        }
      })

      if (res.data.success) {
        wx.showToast({ title: '上报成功', icon: 'success' })
        setTimeout(() => {
          wx.switchTab({ url: '/pages/list/list' })
        }, 1500)
      } else {
        wx.showToast({ title: res.data.message || '上报失败', icon: 'none' })
      }
    } catch (error) {
      console.error('提交失败', error)
      wx.showToast({ title: '提交失败', icon: 'none' })
    } finally {
      this.setData({ submitting: false })
    }
  }
})
