const app = getApp()

Page({
  data: {
    isLoggedIn: false,
    loginForm: {
      phone: '',
      password: ''
    },
    loggingIn: false,
    userInfo: null,
    categories: [],
    stats: {
      total: 0,
      pending: 0,
      processing: 0,
      completed: 0
    },
    recentHazards: []
  },

  onLoad() {
    this.checkLogin()
  },

  onShow() {
    if (this.data.isLoggedIn) {
      this.fetchData()
    }
  },

  checkLogin() {
    const userInfo = wx.getStorageSync('userInfo')
    const token = wx.getStorageSync('token')
    if (userInfo && token) {
      this.setData({ 
        isLoggedIn: true, 
        userInfo 
      })
      app.globalData.userInfo = userInfo
      app.globalData.token = token
      this.fetchData()
    }
  },

  onPhoneInput(e) {
    this.setData({ 'loginForm.phone': e.detail.value })
  },

  onPasswordInput(e) {
    this.setData({ 'loginForm.password': e.detail.value })
  },

  async handleLogin() {
    const { phone, password } = this.data.loginForm
    
    if (!phone || phone.length !== 11) {
      return wx.showToast({ title: '请输入正确的手机号', icon: 'none' })
    }
    if (!password) {
      return wx.showToast({ title: '请输入密码', icon: 'none' })
    }

    this.setData({ loggingIn: true })

    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/user/login`,
        method: 'POST',
        data: { phone, password }
      })

      if (res.data.success) {
        wx.setStorageSync('userInfo', res.data.data)
        wx.setStorageSync('token', res.data.data.token)
        
        this.setData({
          isLoggedIn: true,
          userInfo: res.data.data,
          loginForm: { phone: '', password: '' }
        })
        
        app.globalData.userInfo = res.data.data
        app.globalData.token = res.data.data.token
        
        wx.showToast({ title: '登录成功', icon: 'success' })
        this.fetchData()
      } else {
        wx.showToast({ title: res.data.message || '登录失败', icon: 'none' })
      }
    } catch (error) {
      wx.showToast({ title: '网络错误', icon: 'none' })
    } finally {
      this.setData({ loggingIn: false })
    }
  },

  async fetchData() {
    await Promise.all([
      this.fetchCategories(),
      this.fetchStats(),
      this.fetchRecentHazards()
    ])
  },

  async fetchCategories() {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/categories`,
        method: 'GET'
      })
      this.setData({ categories: res.data.data })
    } catch (error) {
      console.error('获取分类失败', error)
    }
  },

  async fetchStats() {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/statistics`,
        method: 'GET',
        data: { 
          user_id: this.data.userInfo?.id,
          is_admin: 'false'
        },
        header: { 'Authorization': `Bearer ${wx.getStorageSync('token')}` }
      })
      this.setData({ stats: res.data.data })
    } catch (error) {
      console.error('获取统计失败', error)
    }
  },

  async fetchRecentHazards() {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/hazards`,
        method: 'GET',
        data: { 
          pageSize: 5,
          user_id: this.data.userInfo?.id,
          is_admin: 'false'
        },
        header: { 'Authorization': `Bearer ${wx.getStorageSync('token')}` }
      })
      this.setData({ recentHazards: res.data.data.list })
    } catch (error) {
      console.error('获取最近隐患失败', error)
    }
  },

  goToCamera() {
    wx.navigateTo({
      url: '/pages/camera/camera'
    })
  },

  goToReport(e) {
    const categoryId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/report/report?categoryId=${categoryId}`
    })
  },

  goToList() {
    wx.switchTab({
      url: '/pages/list/list'
    })
  },

  goToDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    })
  },

  goToSearch() {
    wx.navigateTo({
      url: '/pages/list/list'
    })
  }
})
