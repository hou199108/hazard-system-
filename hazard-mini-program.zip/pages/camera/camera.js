const app = getApp()

Page({
  data: {
    imagePath: '',
    recognizing: false,
    results: []
  },

  onLoad() {
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo')
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      setTimeout(() => {
        wx.switchTab({ url: '/pages/index/index' })
      }, 1500)
    }
  },

  takePhoto() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        this.setData({ imagePath: tempFilePath })
        this.recognizeImage(tempFilePath)
      }
    })
  },

  chooseFromAlbum() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        this.setData({ imagePath: tempFilePath })
        this.recognizeImage(tempFilePath)
      }
    })
  },

  retakePhoto() {
    this.setData({ imagePath: '', results: [] })
  },

  async recognizeImage(filePath) {
    this.setData({ recognizing: true })

    try {
      const res = await wx.uploadFile({
        url: `${app.globalData.baseUrl}/recognize`,
        filePath: filePath,
        name: 'image'
      })

      const data = JSON.parse(res.data)
      if (data.success) {
        const results = (data.data.results || []).map(item => ({
          ...item,
          confidencePercent: (item.confidence * 100).toFixed(0)
        }));
        this.setData({ 
          results: results,
          recognizing: false
        })
      } else {
        wx.showToast({ title: data.message || '识别失败', icon: 'none' })
        this.setData({ recognizing: false })
      }
    } catch (error) {
      console.error('识别失败', error)
      wx.showToast({ title: '识别失败，请重试', icon: 'none' })
      this.setData({ recognizing: false })
    }
  },

  useResult(e) {
    const item = e.currentTarget.dataset.item
    // 将识别结果传递到上报页面
    const data = encodeURIComponent(JSON.stringify({
      category_id: item.category_id,
      hazard_type_id: item.hazard_type_id,
      title: item.hazard_name,
      ai_description: item.description,
      regulation: item.regulation,
      article: item.article,
      content: item.content,
      image: this.data.imagePath
    }))
    
    wx.navigateTo({
      url: `/pages/report/report?aiData=${data}`
    })
  },

  goToManualReport() {
    wx.navigateTo({
      url: '/pages/report/report'
    })
  }
})
