const app = getApp()

Page({
  data: {
    hazard: null,
    images: [],
    loading: true
  },

  onLoad(options) {
    if (options.id) {
      this.fetchDetail(options.id)
    }
  },

  async fetchDetail(id) {
    try {
      const res = await wx.request({
        url: `${app.globalData.baseUrl}/hazards/${id}`,
        method: 'GET',
        header: { 'Authorization': `Bearer ${wx.getStorageSync('token')}` }
      })

      if (res.data.success) {
        const hazard = res.data.data
        hazard.created_at = this.formatDate(hazard.created_at)
        hazard.handled_at = this.formatDate(hazard.handled_at)

        const images = hazard.images ? hazard.images.split(',').filter(Boolean) : []

        this.setData({
          hazard,
          images,
          loading: false
        })
      }
    } catch (error) {
      console.error('获取详情失败', error)
      this.setData({ loading: false })
    }
  },

  formatDate(dateStr) {
    if (!dateStr) return ''
    const date = new Date(dateStr)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const hour = String(date.getHours()).padStart(2, '0')
    const minute = String(date.getMinutes()).padStart(2, '0')
    return `${year}-${month}-${day} ${hour}:${minute}`
  },

  previewImage(e) {
    const url = e.currentTarget.dataset.url
    wx.previewImage({
      current: url,
      urls: this.data.images
    })
  },

  openMap() {
    const { hazard } = this.data
    if (hazard.latitude && hazard.longitude) {
      wx.openLocation({
        latitude: hazard.latitude,
        longitude: hazard.longitude,
        name: hazard.location,
        scale: 16
      })
    }
  },

  makeCall() {
    const { hazard } = this.data
    if (hazard.reporter_phone) {
      wx.makePhoneCall({
        phoneNumber: hazard.reporter_phone
      })
    }
  }
})
