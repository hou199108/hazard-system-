App({
  globalData: {
    baseUrl: 'http://127.0.0.1:3110/api',
    userInfo: null
  },

  onLaunch() {
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo')
    if (userInfo) {
      this.globalData.userInfo = userInfo
    }
  }
})
